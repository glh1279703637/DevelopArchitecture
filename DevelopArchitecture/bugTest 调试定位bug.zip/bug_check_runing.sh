#在桌面创建目录 bugTest 然后 生成 ios bug调试查找bug所对应的目录

PROJECT_NAME="MZCloudClass"

cd ~/Desktop/

if [ ! -d "bugTest" ]; then
mkdir bugTest
fi

cd bugTest

if [ ! -d "$PROJECT_NAME.crash" ]; then
touch $PROJECT_NAME.crash
fi


if [ ! -d "$PROJECT_NAME.app.dSYM" ]; then
mkdir $PROJECT_NAME.app.dSYM
fi

if [ ! -d "$PROJECT_NAME.app" ]; then
mkdir $PROJECT_NAME.app
fi

if [ ! -d "symbolicatecrash" ]; then
cp /Applications/Xcode.app/Contents/Developer/Platforms/AppleTVSimulator.platform/Developer/Library/PrivateFrameworks/DVTFoundation.framework/symbolicatecrash .
fi

open -e $PROJECT_NAME.crash

echo "是否继续运行:[任何键继续]"
read isopen

export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer

./symbolicatecrash $PROJECT_NAME.crash $PROJECT_NAME.app.dSYM > "$PROJECT_NAME"_log.txt

echo "是否打开Archives目录:[1 打开]"
read isopen
if [[ $isopen == 1 ]];then
open ~/Library/Developer/Xcode/Archives/
fi

#生成一个文件 夹，然后 将下面文件放到此目录下
#symbolicatecrash 、MZCloudClass.app 、MZCloudClass.app.dSYM、MZCloudClass.crash
#
#symbolicatecrash 来源
#/Applications/Xcode.app/Contents/Developer/Platforms/AppleTVSimulator.platform/Developer/Library/PrivateFrameworks/DVTFoundation.framework/symbolicatecrash
#
#MZCloudClass.app 、MZCloudClass.app.dSYM 来源
#/Users/jeffrey/Library/Developer/Xcode/Archives
#
#1.查看xx.app文件的uuid的方法,在命令行中输入
#dwarfdump --uuid MZCloudClass.app/MZCloudClass
#2.查看xx.app.dSYM文件的uuid的方法，在命令行输入
#dwarfdump --uuid MZCloudClass.app.dSYM
#3.查看.crash的uuid，位于crash日志中的Binary Images:中的第一行。如：armv7s  <13760bde0d073f1eb4d596c3df753f4b>
#
#4.生成log.txt文件
#./symbolicatecrash MZCloudClass.crash MZCloudClass.app.dSYM > log.txt
#
#输入上述命令可能会出现Error: "DEVELOPER_DIR" is not defined at ./symbolicatecrash line 53.这个错误。
#如果出现上述错误，输入命令：export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
#
#另外的方法：
#1.atos 命令 解析
#1.1 cd /Users/jeffrey/Desktop/bug/MZCloudClass.app.dSYM/Contents/Resources/DWARF
#1.2 atos -arch arm64 -o dailylife 0x1741ff200
#1.2.2atos -arch armv7 dailylife 0x43f21
#
#2. dwarfdump 命令 解析
#dwarfdump --arch=armv7 --lookup 0x19f095104  /Users/jeffrey/Desktop/bug/MZCloudClass.app.dSYM/Contents/Resources/DWARF/MZCloudClassTest
