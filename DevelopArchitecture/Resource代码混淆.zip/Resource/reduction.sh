#!/usr/bin/env bash

# xcode ->build phases -> run script  $PROJECT_DIR/Resource/confuse.sh
#xcode -> build settings ->prefix header $PROJECT_DIR/Resource/PrefixHeader.pch

#工程名 将XXX替换成自己的工程名
project_name="DevelopArchitecture"

PROJECT_DIR=$(cd `dirname $0`; pwd)
PROJECT_DIR=${PROJECT_DIR%/*}
#PROJECT_DIR="/Users/Jeffrey/Documents/project/MZCloudClass/MZCloudClassDev2/MZCloudClass"

STRING_RESOURCE_FILE="$PROJECT_DIR/Resource"

GCC_PRECOMPILE_PREFIX_FILE="$PROJECT_DIR/${project_name}.xcodeproj/project.pbxproj"

SYMBOL_DB_FILE="$STRING_RESOURCE_FILE/symbols"

CONFUSE_FILE="$PROJECT_DIR/${project_name}"

INSERT_FILE="$STRING_RESOURCE_FILE/infile.tx"
INSERT_FILE2="$STRING_RESOURCE_FILE/infile2.tx"
INSERT_FILE3="$STRING_RESOURCE_FILE/infile3.tx"

TABLENAME=symbols

export LC_CTYPE=C
query()
{
echo "select des from $TABLENAME where src='$1';" | sqlite3 $SYMBOL_DB_FILE
}

cat "$INSERT_FILE" | while read -r line; do
if [[ ! -z "$line" ]]; then
key=`echo $line | awk '{split($0,a," ");print a[1]'}`
values=`echo $line | awk '{split($0,a," ");print a[2]'}`
find $CONFUSE_FILE -iname '*.[mh]' | xargs perl -pi -e "s|@\"$values|@\"$key|g"  #  查找文件内容并且替换 将所有的字符串方法替换成对应宏定义的方法
fi
done

cat "$INSERT_FILE2" | while read -r line; do
if [[ ! -z "$line" ]]; then
key=`echo $line | awk '{split($0,a," ");print a[1]'}`
values=`echo $line | awk '{split($0,a," ");print a[2]'}`
find $CONFUSE_FILE -iname 'J*.[mh]' | xargs perl -pi -e "s|@\"$values\"|@\"$key\"|g"  #  查找文件内容并且替换 将所有的字符串类名替换成对应宏定义的类名
fi
done

cat "$INSERT_FILE3" | while read -r line; do
if [[ ! -z "$line" ]]; then
key=`echo $line | awk '{split($0,a," ");print a[1]'}`
values=`echo $line | awk '{split($0,a," ");print a[2]'}`
find $CONFUSE_FILE -iname 'J*.[mh]' | xargs perl -pi -e "s|@\"$values\"|@\"$key\"|g"  #  查找文件内容并且替换 将所有的字符串属性替换成对应宏定义的属性
fi
done

line="GCC_PRECOMPILE_PREFIX_HEADER = NO;"
line2="GCC_PREFIX_HEADER = \"\";"
ramdom="GCC_PRECOMPILE_PREFIX_HEADER = YES;"
ramdom2="GCC_PREFIX_HEADER = $PROJECT_DIR/Resource/PrefixHeader.pch;"

find $GCC_PRECOMPILE_PREFIX_FILE | xargs perl -pi -e "s|$ramdom|$line|g"  #  查找文件内容并且替换
find $GCC_PRECOMPILE_PREFIX_FILE | xargs perl -pi -e "s|$ramdom2|$line2|g"  #  查找文件内容并且替换
