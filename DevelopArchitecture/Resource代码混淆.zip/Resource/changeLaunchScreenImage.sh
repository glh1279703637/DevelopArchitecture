#!/usr/bin/env bash

#工程名 将XXX替换成自己的工程名
project_name="DevelopArchitecture"

PROJECT_DIR=$(cd `dirname $0`; pwd)
PROJECT_DIR=${PROJECT_DIR%/*}

CONFUSE_FILE="$PROJECT_DIR/${project_name}"

GCC_PRECOMPILE_PREFIX_FILE="$PROJECT_DIR/${project_name}.xcodeproj/project.pbxproj"
LAUNCHSCREE_FILE="$PROJECT_DIR/${project_name}/Base.lproj/LaunchScreen.storyboard"

IMAGE_PATH_FILE="$CONFUSE_FILE/image"


export LC_CTYPE=C

cd $IMAGE_PATH_FILE

#launchscreen 图片在打包的时候进行改名
DATE=`date +%F | sed 's/-//g'``date +%T | sed 's/://g'`
for file in `ls | grep launch_`
do
newfile=`echo $file | sed "s/@2x/__${DATE}@2x/g"`
file1=`echo $file | sed "s/@2x.png//g"`
file2=`echo $file | sed "s/@2x.png/__${DATE}/g"`
mv $file $newfile
find $GCC_PRECOMPILE_PREFIX_FILE | xargs perl -pi -e "s|${file1}|${file2}|g"  #  查找文件内容并且替换
find $LAUNCHSCREE_FILE | xargs perl -pi -e "s|${file1}|${file2}|g"  #  查找文件内容并且替换
done



#launchscreen 图片被上边编译后修改的还原
pngfile="__"
for file in `ls | grep launch_`
do
file1=`echo $file | sed "s/@2x.png//g"`
file2=`echo ${file1%${pngfile}*}`
newfile=${file2}"@2x.png"

mv $file $newfile
find $GCC_PRECOMPILE_PREFIX_FILE | xargs perl -pi -e "s|${file1}|${file2}|g"  #  查找文件内容并且替换
find $LAUNCHSCREE_FILE | xargs perl -pi -e "s|${file1}|${file2}|g"  #  查找文件内容并且替换
done
