#!/usr/bin/env bash

# xcode ->build phases -> run script  $PROJECT_DIR/Resource/confuse.sh
#xcode -> build settings ->prefix header $PROJECT_DIR/Resource/PrefixHeader.pch


#工程名 将XXX替换成自己的工程名
project_name="DevelopArchitecture"


PROJECT_DIR=$(cd `dirname $0`; pwd)
PROJECT_DIR=${PROJECT_DIR%/*}
#PROJECT_DIR="/Users/Jeffrey/Documents/project/MZCloudClass/MZCloudClassDev2/MZCloudClass"
CONFUSE_FILE="$PROJECT_DIR/${project_name}"

STRING_RESOURCE_FILE="$PROJECT_DIR/Resource"

GCC_PRECOMPILE_PREFIX_FILE="$PROJECT_DIR/${project_name}.xcodeproj/project.pbxproj"

SYMBOL_DB_FILE="$STRING_RESOURCE_FILE/symbols"
STRING_SYMBOL_FILE="$STRING_RESOURCE_FILE/func.list"
STRING_SYMBOL_FILE2="$STRING_RESOURCE_FILE/func2.list"
STRING_SYMBOL_FILE3="$STRING_RESOURCE_FILE/func3.list"

HEAD_FILE="$STRING_RESOURCE_FILE/codeObfuscation.h"
INSERT_FILE="$STRING_RESOURCE_FILE/infile.tx"
INSERT_FILE2="$STRING_RESOURCE_FILE/infile2.tx"
INSERT_FILE3="$STRING_RESOURCE_FILE/infile3.tx"

TABLENAME=symbols


export LC_CTYPE=C
#方法
#取以.m或.h结尾的文件以+号或-号开头的行 |去掉所有+号或－号|用空格代替符号|n个空格跟着<号 替换成 <号|开头不能是IBAction|用空格split字串取第二部分|排序|去重复|删除空行|删掉以init开头的行>写进func.list
grep -h -r -I  "^[ ]*[-+]" $CONFUSE_FILE  --include '*.[mh]' |sed "s/[+-]//g"|sed "s/[();,: *\^\/\{]/ /g"|sed "s/[ ]*<.*>/ /"| sed "/^[ ]*IBAction/d"|awk '{split($0,b," "); print b[2]; }'| sort -r|uniq |sed "/^$/d"|sed -n "/^funj_/p" >$STRING_SYMBOL_FILE
##grep -h -r -I  "^[-+]" $CONFUSE_FILE  --include '*.[mh]' |sed "s/[+-]//g"|sed "s/[();,: *\^\/\{]/ /g"|sed "s/[ ]*</</"| sed "/^[ ]*IBAction/d"|awk '{split($0,b," "); print b[2]; }'| sort|uniq |sed "/^$/d" >$STRING_SYMBOL_FILE

#类
#取以.m或.h结尾的文件以@interface号开头的行 |去掉所有@interface|用空格代替符号|n个空格跟着<号 替换成 <号|用空格split字串取第二部分|排序|去重复|删除空行|删掉以init开头的行>写进func.list
grep -h -r -I  "^[ ]*@interface" $CONFUSE_FILE  --include 'J*.[h]' |sed "s/[@]//g"|sed "s/[();,: *\^\/\{]/ /g"|awk '{split($0,b," "); print b[2]; }'| sort -r|uniq |sed "/^$/d"|sed -n "/^J/p" >$STRING_SYMBOL_FILE2

#属性
#取J开头及以.m或.h结尾的文件以@property号开头的行 |去掉所有@interface|用空格代替符号|n个空格跟着<号 替换成 <号|用空格split字串取第五部分|排序|去重复|删除空行|删掉以init开头的行>写进func.list
grep -h -r -I  "^[ ]*@property" $CONFUSE_FILE  --include 'J*.[mh]' |sed "s/[@]//g"|sed "s/[;,: *\^\/\{]/ /g"|sed "s/[ ]*(.*)/ /"|sed "s/[ ]*<.*>/ /"|awk '{split($0,b," "); for(i=3;i<=6;i++){print b[i];}; }'| sort -r|uniq |sed "/^$/d"|sed -n "/^m_/p" >$STRING_SYMBOL_FILE3


arr=("JPushNotificationContent" "JPushNotificationIdentifier" "JPushNotificationRequest" "JPushNotificationTrigger" "JPUSHRegisterEntity" "JPUSHService" "JMainTabBarVC" "JMainViewController")
for i in "${!arr[@]}";do
find $STRING_RESOURCE_FILE -iname '*.list' | xargs perl -pi -e "s|${arr[$i]}||g"  #  查找文件内容并且替换 将所有的属性替换成对应宏定义的属性
done


#维护数据库方便日后作排重,一下代码来自念茜的微博
createTable()
{
echo "create table $TABLENAME(src text, des text);" | sqlite3 $SYMBOL_DB_FILE
}

insertValue()
{
echo "insert into $TABLENAME values('$1' ,'$2');" | sqlite3 $SYMBOL_DB_FILE
}

query()
{
echo "select des from $TABLENAME where src='$1';" | sqlite3 $SYMBOL_DB_FILE
}

ramdomString()
{
openssl rand -base64 64 | tr -cd 'a-zA-Z_' |head -c 5

}

#rm -f $SYMBOL_DB_FILE
rm -f $HEAD_FILE
rm -f $INSERT_FILE
createTable

touch $HEAD_FILE
echo '#ifndef Demo_codeObfuscation_h
#define Demo_codeObfuscation_h' >> $HEAD_FILE
echo "//confuse string at `date`" >> $HEAD_FILE

cat "$STRING_SYMBOL_FILE" | while read -ra line; do #方法
if [[ ! -z "$line" ]]; then
ramdom=`query "$line"`
if [[ -z "$ramdom" ]]; then
ramdom=`ramdomString`
insertValue $line $ramdom
fi
#echo $line $ramdom
echo "#define $line $ramdom" >> $HEAD_FILE
#find $CONFUSE_FILE -iname "*.*" | xargs perl -pi -e "s|$line|funj_$line|g"  #  查找文件内容并且替换 将所有函数替换成funj_开头的函数

ishas=$(grep -h -r -I "@\"$line" $CONFUSE_FILE  --include 'J*.[mh]' | wc -l | awk '{print $1}')
if [ $ishas -gt 0 ];then
find $CONFUSE_FILE -iname 'J*.[mh]' | xargs perl -pi -e "s|@\"$line|@\"$ramdom|g"  #  查找文件内容并且替换 将所有的字符串方法替换成对应宏定义的方法
echo "$line $ramdom" >> $INSERT_FILE
fi

fi
done

cat "$STRING_SYMBOL_FILE2" | while read -ra line; do #类
if [[ ! -z "$line" ]]; then
ramdom=`query "$line"`
if [[ -z "$ramdom" ]]; then
ramdom=`ramdomString`
insertValue $line $ramdom
fi
#echo $line $ramdom
echo "#define $line $ramdom" >> $HEAD_FILE

ishas=$(grep -h -r -I "@\"$line\"" $CONFUSE_FILE  --include 'J*.[mh]' | wc -l | awk '{print $1}')
if [ $ishas -gt 0 ];then
find $CONFUSE_FILE -iname 'J*.[mh]' | xargs perl -pi -e "s|@\"$line\"|@\"$ramdom\"|g"  #  查找文件内容并且替换 将所有的字符串类名替换成对应宏定义的类名
echo "$line $ramdom" >> $INSERT_FILE2
fi

fi
done

cat "$STRING_SYMBOL_FILE3" | while read -ra line; do #属性
if [[ ! -z "$line" ]]; then
ramdom=`query "$line"`
if [[ -z "$ramdom" ]]; then
ramdom=`ramdomString`
ramdom=m_$ramdom
insertValue $line $ramdom
fi
#echo $line $ramdom
echo "#define $line $ramdom" >> $HEAD_FILE
echo "#define _$line _$ramdom" >> $HEAD_FILE
echo "#define setM${line:1} setM${ramdom:1}" >> $HEAD_FILE

ishas=$(grep -h -r -I "@\"$line\"" $CONFUSE_FILE  --include 'J*.[mh]' | wc -l | awk '{print $1}')
if [ $ishas -gt 0 ];then
find $CONFUSE_FILE -iname 'J*.[mh]' | xargs perl -pi -e "s|@\"$line\"|@\"$ramdom\"|g"  #  查找文件内容并且替换 将所有的字符串属性替换成对应宏定义的属性
echo "$line $ramdom" >> $INSERT_FILE3
fi

fi
done

line="GCC_PRECOMPILE_PREFIX_HEADER = NO;"
line2="GCC_PREFIX_HEADER = \"\";"
ramdom="GCC_PRECOMPILE_PREFIX_HEADER = YES;"
ramdom2="GCC_PREFIX_HEADER = $PROJECT_DIR/Resource/PrefixHeader.pch;"

find $GCC_PRECOMPILE_PREFIX_FILE | xargs perl -pi -e "s|$line|$ramdom|g"  #  查找文件内容并且替换
find $GCC_PRECOMPILE_PREFIX_FILE | xargs perl -pi -e "s|$line2|$ramdom2|g"  #  查找文件内容并且替换

echo "#endif" >> $HEAD_FILE


#sqlite3 $SYMBOL_DB_FILE .dump

echo "######";echo "";
echo 'xcode -> build settings ->prefix header $PROJECT_DIR/Resource/PrefixHeader.pch'
echo "";echo "######";
