//
//  BuddyList.swift
//  BuddyMultiDelegateDemo
//
//  Created by iDevFans on 16/9/26.
//  Copyright © 2016年 macdev. All rights reserved.
//

import Cocoa

class BuddyList: MModel {
    var ID = 0
    var nickName = ""
    var status = false
}
