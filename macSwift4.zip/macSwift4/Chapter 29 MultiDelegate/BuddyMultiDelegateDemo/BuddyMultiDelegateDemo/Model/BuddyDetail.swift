//
//  BuddyDetail.swift
//  BuddyMultiDelegateDemo
//
//  Created by iDevFans on 16/9/26.
//  Copyright © 2016年 macdev. All rights reserved.
//

import Cocoa

class BuddyDetail: MModel {
    var ID = 0
    var firstName = ""
    var lastName = ""
    var address = ""
    var birthDay = ""
    var image = ""
}
