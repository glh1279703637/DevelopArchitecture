//
//  LocalizationManager.swift
//  LocalizationTools
//
//  Created by iDevFans on 16/9/1.
//  Copyright © 2016年 macdev. All rights reserved.
//

import Cocoa

class LocalizationManager: NSObject {

}
