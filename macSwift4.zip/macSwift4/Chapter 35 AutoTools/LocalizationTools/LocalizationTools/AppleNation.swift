//
//  AppleNation.swift
//  LocalizationTools
//
//  Created by iDevFans on 16/8/28.
//  Copyright © 2016年 macdev. All rights reserved.
//

import Cocoa

class AppleNation: Nation {
 
}

