//
//  Nation.swift
//  LocalizationTools
//
//  Created by iDevFans on 16/9/3.
//  Copyright © 2016年 macdev. All rights reserved.
//

import Cocoa

class Nation: MModel {
    var ID: Int = 0
    var code: String?
    var name: String?
    var chinaName: String?
    var alias: String?
}
