//
//  MouseAutoClick.h
//  LocalizationTools
//
//  Created by iDevFans on 16/9/3.
//  Copyright © 2016年 macdev. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MouseAutoClick : NSObject
+ (void)postClickAt:(NSPoint)point ;
@end
