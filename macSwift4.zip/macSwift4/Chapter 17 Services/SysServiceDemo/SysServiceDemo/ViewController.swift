//
//  ViewController.swift
//  SysServiceDemo
//
//  Created by iDevFans on 16/7/31.
//  Copyright © 2016年 macdev. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }




}

