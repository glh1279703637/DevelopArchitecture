//
//  DataField.swift
//  DataTransformer
//
//  Created by iDevFans on 16/8/12.
//  Copyright © 2016年 macdev. All rights reserved.
//

import Cocoa
class DataField: NSObject {
    var name: String?
    var type: Int = 0
}
