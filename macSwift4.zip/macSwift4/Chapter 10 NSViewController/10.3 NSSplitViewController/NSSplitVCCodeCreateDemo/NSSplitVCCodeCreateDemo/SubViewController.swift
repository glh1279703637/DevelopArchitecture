//
//  SubViewController.swift
//  NSSplitVCCodeCreateDemo
//
//  Created by iDevFans on 16/7/19.
//  Copyright © 2016年 http://macdev.io. All rights reserved.
//

import Cocoa

class SubViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
