//
//  Subjects+CoreDataClass.swift
//  SchoolV2
//
//  Created by iDevFans on 16/8/14.
//  Copyright © 2016年 macdev. All rights reserved.
//

import Foundation
import CoreData


public class Subjects: NSManagedObject {

}
