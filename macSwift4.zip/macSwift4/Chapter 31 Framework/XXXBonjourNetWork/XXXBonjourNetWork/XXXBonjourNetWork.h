//
//  XXXBonjourNetWork.h
//  XXXBonjourNetWork
//
//  Created by iDevFans on 16/10/23.
//  Copyright © 2016年 macdev. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for XXXBonjourNetWork.
FOUNDATION_EXPORT double XXXBonjourNetWorkVersionNumber;

//! Project version string for XXXBonjourNetWork.
FOUNDATION_EXPORT const unsigned char XXXBonjourNetWorkVersionString[];

// In this header, you should import all the public headers of your framework using statements like

#import "Helper.h"
