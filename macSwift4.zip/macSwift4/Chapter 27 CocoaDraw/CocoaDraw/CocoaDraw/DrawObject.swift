//
//  DrawObject.swift
//  CocoaDraw
//
//  Created by iDevFans on 16/10/9.
//  Copyright © 2016年 macdev. All rights reserved.
//

import Cocoa

class DrawObject: NSObject {
    var bounds: NSRect = NSZeroRect
    func draw(){
        
    }
}
