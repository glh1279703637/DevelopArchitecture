//
//  AppViewController.swift
//  NSWindowArchitecture
//
//  Created by iDevFans on 16/7/13.
//  Copyright © 2016年 http://macdev.io. All rights reserved.
//

import Cocoa

class AppViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
