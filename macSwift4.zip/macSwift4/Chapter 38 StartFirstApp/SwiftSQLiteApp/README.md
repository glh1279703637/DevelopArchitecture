# SwiftSQLiteApp
simple SQLite database management for OS X,this is an unfinished project http://www.macdev.io/

![SQLiteApp Logic Architecture](https://github.com/javaliker/SwiftSQLiteApp/blob/master/SQLiteAppLogicArchitecture.png) 

 ![Browse Data](https://github.com/javaliker/SwiftSQLiteApp/blob/master/Browse.png) 
 
 ![Schema](https://github.com/javaliker/SwiftSQLiteApp/blob/master/Schema.png) 
  
![Query](https://github.com/javaliker/SwiftSQLiteApp/blob/master/Query.png) 
