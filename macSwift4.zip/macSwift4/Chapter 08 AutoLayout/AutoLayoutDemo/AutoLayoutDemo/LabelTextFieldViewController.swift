//
//  LabelTextFieldViewController.swift
//  AutoLayoutDemo
//
//  Created by iDevFans on 16/9/25.
//  Copyright © 2016年 macdev. All rights reserved.
//

import Cocoa

class LabelTextFieldViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}
