####

#project_path="/Users/jeffrey/Documents/MZCloudClass/MZCloudClassApp/MZCloudClass"
#工程绝对路径
project_path=$(cd `dirname $0`; pwd)
project_path=${project_path%/*}
cd $project_path

function startGitPullNewSourceCode () {
    git_branchName=$1

    echo "//--- -- start git $git_branchName ---"
    git checkout $git_branchName
    git pull origin $git_branchName
    git branch
    echo "//--- -- start 打包 $git_branchName ---"
    $project_path/AutoArchive/shell
    echo "//--- -- --- --- -- --- --- -- --- --- -- ---"
    echo "//--- -- --- --- -- --- --- -- --- --- -- ---"
}



startGitPullNewSourceCode "changeWhiteboard3"
startGitPullNewSourceCode "JiaCai1"
startGitPullNewSourceCode "SevenLemon1"

