#使用方法
#https://www.jianshu.com/p/05dc9f925467
#  method 包含四种： app-store, ad-hoc, enterprise, development



#工程名 将XXX替换成自己的工程名
project_name="DevelopArchitecture"

#scheme名 将XXX替换成自己的sheme名
scheme_name="DevelopArchitecture"

pgy_uKey1="11a8f40cfb4ac9b170bfe275aa51c47d" #测试pgy账号的 固定的 https://www.pgyer.com/doc/api 获取
pgy_apiKey1="db4a69c6d4f894bcb378ae69b62e25cf" #测试pgy账号的  固定的

pgy_uKey2="f3dbbebbc9aa275293449de9cf95f55c" #正式pgy账号的 固定的
pgy_apiKey2="f03f8225664b0705dbc1f52180a8d6fc" #正式pgy账号的 固定的

appstore_ID=""
appstore_pwd=""


#只是定义 不需要填值
pgy_uKey=""  #蒲公英用户id   https://www.pgyer.com/doc/api 获取
pgy_apiKey="" #蒲公英用户id

#工程绝对路径
project_path=$(cd `dirname $0`; pwd)
project_path=${project_path%/*}

user_id=$(echo "$USER")
build_archives_path="/Users/$user_id/Library/Developer/Xcode/Archives"

#打包模式 Debug/Release
development_mode=Release

#build文件夹路径
build_path=${project_path}/build

#plist文件所在路径
exportOptionsPlistPath=${project_path}/AutoArchive/shellconfig.plist

#导出.ipa文件所在路径
exportIpaPath=${project_path}/IPADir
ipa_filePath="${exportIpaPath}/${scheme_name}.ipa"

cd $project_path
#pgy 更新日志内容
#pgy_updateDescription="1.更新界面 2.修正bug"
pgy_updateDescription=$(cat AutoArchive/updateDescription.txt)
pgy_PublicName=$(/usr/libexec/PlistBuddy -c "Print archiveAppConfig:pgyPublicName" $exportOptionsPlistPath)

# 全局c参数配置
isMulSignature=0
exportType=0
pgyUploadAccount=0

#### 前期输入
function startConfig () {
    rm -rf build
    rm -rf IPADir

    if [ ! -d ./IPADir ];
    then
    mkdir -p IPADir;
    fi

    echo "To publish multiple apps using re-signature, please enter ? [ 1:only one 2:Publish multiple apps ]"
    read isMulSignature
    while([[ $isMulSignature != 1 ]] && [[ $isMulSignature != 2 ]])
    do
    echo "Error! Should enter 1 or 2"
    echo "To publish multiple apps using re-signature, please enter ? [ 1:only one 2:Publish multiple apps ]"
    read isMulSignature
    done

    echo "Please enter the number you want to export ? [ 1:enterprise 2:app-store 3:ad-hoc] "
    read exportType
    while([[ $exportType != 1 ]] && [[ $exportType != 2 ]] && [[ $exportType != 3 ]])
    do
    echo "Error! Should enter 1 or 2 or 3"
    echo "Please enter the number you want to export ? [ 1:enterprise 2:app-store 3:ad-hoc] "
    read exportType
    done
    if [ $exportType == 1 ];then
    /usr/libexec/PlistBuddy -c 'Set :method "enterprise"' $exportOptionsPlistPath

    echo "Please enter the number you want to upload to pgy ? [ 1:test-pgy 2:produce-pgy 3:none] "
    read pgyUploadAccount
    while([[ $pgyUploadAccount != 1 ]] && [[ $pgyUploadAccount != 2 ]] && [[ $pgyUploadAccount != 3 ]])
    do
    echo "Error! Should enter 1 or 2 or 3"
    echo "Please enter the number you want to upload to pgy ? [ 1:test-pgy 2:produce-pgy 3:none] "
    read pgyUploadAccount
    done
    if [ $pgyUploadAccount == 1 ];then
    pgy_uKey=$pgy_uKey1
    pgy_apiKey=$pgy_apiKey1;
    elif [ $pgyUploadAccount == 2 ];then
    pgy_uKey=$pgy_uKey2
    pgy_apiKey=$pgy_apiKey2;
    fi

    elif [ $exportType == 2 ];then
    /usr/libexec/PlistBuddy -c 'Set :method "app-store"' $exportOptionsPlistPath

    else
    pgyUploadAccount=1
    /usr/libexec/PlistBuddy -c 'Set :method "ad-hoc"' $exportOptionsPlistPath

    pgy_uKey=$pgy_uKey1
    pgy_apiKey=$pgy_apiKey1;
    fi
}
#### 编译工程
function startXcodebuild_archive () {
    echo '///-----------'
    echo '/// 正在清理工程'
    echo '///-----------'
    xcodebuild \
    clean -configuration ${development_mode} -quiet  || exit

    echo '///--------'
    echo '/// 清理完成'
    echo '///--------'
    echo ''

    echo '///-----------'
    echo '/// 正在编译工程:'${development_mode}
    echo '///-----------'

    if [ -e ${project_path}/${project_name}.xcworkspace ]; then
    xcodebuild \
    archive -workspace ${project_path}/${project_name}.xcworkspace \
    -scheme ${scheme_name} \
    -configuration ${development_mode} \
    -archivePath ${build_path}/${scheme_name}.xcarchive  -quiet  || exit
    else
    xcodebuild \
    archive -project ${project_path}/${project_name}.xcodeproj \
    -scheme ${scheme_name} \
    -configuration ${development_mode} \
    -archivePath ${build_path}/${scheme_name}.xcarchive  -quiet  || exit
    fi

    echo '///--------'
    echo '/// 编译完成'
    echo '///--------'
    echo ''
}
#### 重新签名app
function restartSignedApp () {
#plist文件所在路径
    echo '///----------'
    echo '/// 开始app签名'
    echo '///----------'
    app_filePath=${build_path}/${scheme_name}.xcarchive/Products/Applications
    SOURCE_APP=${app_filePath}/$(ls $app_filePath/)

    numindex=0
    archiveAppIconName=$(/usr/libexec/PlistBuddy -c "Print archiveAppConfig:assetsAppIconName" $exportOptionsPlistPath)
    dis_resourcePath=$(/usr/libexec/PlistBuddy -c "Print mulAppimagesourcePath:$numindex" $exportOptionsPlistPath)
    dis_mobileprovision=$(/usr/libexec/PlistBuddy -c "Print mulAppDevelopMobileProv:$numindex" $exportOptionsPlistPath)
    dis_mulAppBundleID=$(/usr/libexec/PlistBuddy -c "Print mulAppBundleID:$numindex" $exportOptionsPlistPath)
    dis_sourceInfoPath=$(/usr/libexec/PlistBuddy -c "Print mulAppplistsourcePath:$numindex" $exportOptionsPlistPath)
    bundleName=$(/usr/libexec/PlistBuddy -c "Print mulApppbundleName:$numindex" $exportOptionsPlistPath)
    assetsAppIconName=$(/usr/libexec/PlistBuddy -c "Print mulApppassetsAppIconName:$numindex" $exportOptionsPlistPath)
    executableName=$(/usr/libexec/PlistBuddy -c "Print CFBundleExecutable" $SOURCE_APP/Info.plist)

    dis_mobileprovision=${project_path}/AutoArchive/Dis_Mobileprovision/$dis_mobileprovision
    appDevelopCer=$(/usr/libexec/PlistBuddy -c "Print appDevelopCer" $exportOptionsPlistPath)

    rm -rf ${build_path}/${scheme_name}"copy".xcarchive
    cp -rf ${build_path}/${scheme_name}.xcarchive ${build_path}/${scheme_name}"copy".xcarchive

    while([[ $dis_resourcePath ]])
    do

    find $SOURCE_APP -iname "*$archiveAppIconName*" -exec rm -rf {} +
    cp -rf ${project_path}/AutoArchive/Dif_Resource/$dis_resourcePath/ $SOURCE_APP

#拷贝描述文件
    cp -rf "$dis_mobileprovision" "$SOURCE_APP/embedded.mobileprovision"
# 将A.plist 合并到 sourceInfoPath.plist中 相同保留sourceInfoPath 内容
    /usr/libexec/PlistBuddy -c "Merge $SOURCE_APP/Info.plist"  "${project_path}/AutoArchive/Dis_Plists/$dis_sourceInfoPath"
    cp -rf "${project_path}/AutoArchive/Dis_Plists/$dis_sourceInfoPath" "$SOURCE_APP/Info.plist"
    /usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier $dis_mulAppBundleID" "$SOURCE_APP/Info.plist"
    /usr/libexec/PlistBuddy -c "Set :CFBundleExecutable $executableName" "$SOURCE_APP/Info.plist"
    /usr/libexec/PlistBuddy -c "Set :CFBundleName $bundleName" "$SOURCE_APP/Info.plist"
    sed -i ".bak" "s/$archiveAppIconName/$assetsAppIconName/g" "$SOURCE_APP/Info.plist"
    rm -rf "$SOURCE_APP/Info.plist.bak"

#扫描APP里所有需要重签名的组件，包括app/appex/framework/dylib
    RESIGN_FILES="resign_file.txt"
    find -d $SOURCE_APP  \( -name "*.app" -o -name "*.appex" -o -name "*.framework" -o -name "*.dylib" \) > "$RESIGN_FILES"

#获取描述文件里的授权机制(entitlements.plist)
    RESIGN_ENTITLEMWNTS_FULL="entitlements_full.plist"
    RESIGN_ENTITLEMWNTS="entitlements.plist"
    security cms -D -i "$SOURCE_APP/embedded.mobileprovision" > "$RESIGN_ENTITLEMWNTS_FULL"
    /usr/libexec/PlistBuddy -x -c 'Print:Entitlements' "$RESIGN_ENTITLEMWNTS_FULL" > "$RESIGN_ENTITLEMWNTS"

#签名
    while IFS='' read -r line || [[ -n "$line" ]]; do
     /usr/bin/codesign --continue -f -s "$appDevelopCer" --entitlements "$RESIGN_ENTITLEMWNTS"  "$line"
    done < "$RESIGN_FILES"

    rm -rf $RESIGN_ENTITLEMWNTS
    rm -rf $RESIGN_ENTITLEMWNTS_FULL

    ipa_filePath="${project_path}/IPADir/${scheme_name}.ipa"


    echo '///----------'
    echo "/// app[$dis_resourcePath]签名成功"
    echo "Created app: $SOURCE_APP"
    echo '///----------'

    pgy_PublicName=$bundleName #设置pgy 上传版本时显示名称
    startExportArchive  #调用生成ipa
    startPublicArchive #调用发布ipa
    startSendPostBugCloseTip #发布到bugclose 提示更新
    saveToMacDeveloperDirectionry # 保存到developer 目录中，方便后期 bugcrash 查询

    if [ -e $ipa_filePath ]; then
    cp -rf $ipa_filePath $exportIpaPath/$dis_resourcePath.ipa
    echo '///----------'
    echo "/// ipa包复制到 $dis_resourcePath.ipa"
    echo '///----------'
    fi

    rm -rf "${build_path}/${scheme_name}.xcarchive"
    cp -rf "${build_path}/${scheme_name}copy.xcarchive" "${build_path}/${scheme_name}.xcarchive"
    rm -rf "$RESIGN_FILES"


    numindex=$((numindex+1))
    dis_resourcePath=$(/usr/libexec/PlistBuddy -c "Print mulAppimagesourcePath:$numindex" $exportOptionsPlistPath)
    dis_mobileprovision=$(/usr/libexec/PlistBuddy -c "Print mulAppDevelopMobileProv:$numindex" $exportOptionsPlistPath)
    dis_mulAppBundleID=$(/usr/libexec/PlistBuddy -c "Print mulAppBundleID:$numindex" $exportOptionsPlistPath)
    bundleName=$(/usr/libexec/PlistBuddy -c "Print mulApppbundleName:$numindex" $exportOptionsPlistPath)
    dis_sourceInfoPath=$(/usr/libexec/PlistBuddy -c "Print mulAppplistsourcePath:$numindex" $exportOptionsPlistPath)
    assetsAppIconName=$(/usr/libexec/PlistBuddy -c "Print mulApppassetsAppIconName:$numindex" $exportOptionsPlistPath)
     dis_mobileprovision=${project_path}/AutoArchive/Dis_Mobileprovision/$dis_mobileprovision
    done
    rm -rf "${build_path}/${scheme_name}copy.xcarchive"
}
#### 打包生成ipa包
function startExportArchive () {
    echo '///----------'
    echo '/// 开始ipa打包'
    echo '///----------'

    xcodebuild -exportArchive -archivePath ${build_path}/${scheme_name}.xcarchive \
    -configuration ${development_mode} \
    -exportPath ${exportIpaPath} \
    -exportOptionsPlist ${exportOptionsPlistPath} \
    -quiet || exit

    if [ -e $ipa_filePath ]; then
    echo '///----------'
    echo '/// ipa包已导出'
    echo '///----------'
    else
    echo '///-------------'
    echo '/// ipa包导出失败 '
    echo '///-------------'
    fi
    echo '///------------'
    echo '/// 打包ipa完成  '
    echo '///-----------='
    echo ''
}
#### 发布ipa包
function startPublicArchive () {
    echo '///-------------'
    echo '/// 开始发布ipa包 '
    echo '///-------------'

    if [ $exportType == 2 ];then

#验证并上传到App Store
# 将-u 后面的XXX替换成自己的AppleID的账号，-p后面的XXX替换成自己的密码
    altoolPath="/Applications/Xcode.app/Contents/Applications/Application Loader.app/Contents/Frameworks/ITunesSoftwareService.framework/Versions/A/Support/altool"
    "$altoolPath" --validate-app -f ${ipa_filePath} -u $appstore_ID -p $appstore_pwd -t ios --output-format xml
    "$altoolPath" --upload-app -f ${ipa_filePath} -u  $appstore_ID -p $appstore_pwd -t ios --output-format xml
    else
##上传到蒲公英
    if [ $pgyUploadAccount != 3 ];then
    curl -F "file=@$ipa_filePath" \
    -F "uKey=$pgy_uKey" \
    -F "_api_key=$pgy_apiKey" \
    -F "installType=2" \
    -F "password=111111" \
    -F "name=$pgy_PublicName" \
    -F "updateDescription=$pgy_updateDescription" \
    http://www.pgyer.com/apiv1/app/upload
    fi
    fi
}
#发布到bugclose 提示更新
function startSendPostBugCloseTip () {
    result=$(curl -d "email=ganlonghai%40mizholdings.com&password=glh3877542547&inviteCode=" https://www.bugclose.com/cgi/user/login)
token=$(echo ${result:11:32})

    app_filePath=${build_path}/${scheme_name}.xcarchive/Products/Applications
    SOURCE_APP=${app_filePath}/$(ls $app_filePath/)
    bundleVersion=$(/usr/libexec/PlistBuddy -c "Print CFBundleShortVersionString" $SOURCE_APP/Info.plist)

    curl -d "noticeType=VersionRelease&title=${pgy_PublicName}&description=$pgy_updateDescription&imageIds=&attachmentIds=&top=false&notify=true&token=$token&projectId=23815" https://www.bugclose.com/cgi/notice/add

    curl -d "productId=11711&name=$bundleVersion&downloadUrl=&notes=${pgy_updateDescription}&notify=true&imageIds=&attachmentIds=&token=$token&projectId=23815" https://www.bugclose.com/cgi/version/add
}
# 保存到developer 目录中，方便后期 bugcrash 查询
function saveToMacDeveloperDirectionry () {
#将build保存到系统中
    ls_date=`date +%Y-%m-%d`
    if [ ! -d $build_archives_path/$ls_date ];
    then
        mkdir -p $ls_date;
        mv  $ls_date $build_archives_path/$ls_date
    fi

    ls_date_time=`date +"%Y-%m-%d %H.%M"`
    cp -rf "${build_path}/${scheme_name}.xcarchive" "$build_archives_path/$ls_date/${scheme_name} $ls_date_time.xcarchive"
    cp -rf "$ipa_filePath" "$build_archives_path/$ls_date/${scheme_name} $ls_date_time.ipa"
}


startConfig #调用配置
startXcodebuild_archive #调用开始编译
if [ $isMulSignature == 2 ];then
restartSignedApp #开始签名
fi
pgy_PublicName=$(/usr/libexec/PlistBuddy -c "Print archiveAppConfig:pgyPublicName" $exportOptionsPlistPath)
startExportArchive #调用生成ipa
startPublicArchive #调用发布ipa

startSendPostBugCloseTip #发布到bugclose 提示更新
saveToMacDeveloperDirectionry # 保存到developer 目录中，方便后期 bugcrash 查询

rm -rf "${build_path}"
rm -rf "${exportIpaPath}"

exit 0



